from django.apps import AppConfig


class DockerappConfig(AppConfig):
    name = 'dockerApp'
